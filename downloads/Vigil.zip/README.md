# Vigil

A softened geometric grotesk for body copy. Designed by Joaquin Keno Vigil, 2026.
Derived from Figtree (Erik Kennedy) under the SIL Open Font License 1.1.

## Files
- variable/  Vigil[wght] and Vigil-Italic[wght], .ttf and .woff2 — one axis, wght 200–900
- ttf/       16 static instances (ExtraLight → Black, roman + italic), hinted .ttf and .woff2
- otf/       the same 16 instances as CFF OpenType, plus Vigil Outline Regular + Italic
- outline/   Vigil Outline Regular + Italic (.ttf, .woff2) — a display style stroked from Bold; 40px and up only
- Vigil-specimen.html  single-file specimen with a live weight slider

## Weights
ExtraLight 200 is extrapolated beyond the drawn masters and is a display weight: 40px and above, never for body copy.
Vigil Outline is a separate style, not a point on the weight axis: a 22-unit round-joined stroke on the Bold outlines. Family name "Vigil Outline".
Static TTFs are hinted (ttfautohint) for Windows; OTF, variable, and Outline are unhinted.

## Install
Mac: double-click any .otf or .ttf → Install Font. For the variable font use variable/Vigil[wght].ttf.
Web: use the .woff2 files with the @font-face block in the specimen.

## Design rules
- Base: Figtree geometric skeleton, large x-height, double-story a, single-story g
- Rounding by hierarchy: 22 units at exposed terminals, 10 at structural corners, 4 inside joins; none on punctuation; t and f held to the structural level
- Spacing and kerning inherited from Figtree unchanged

## License
SIL Open Font License 1.1 — free for personal and commercial use, including embedding and web use. See OFL.txt.
